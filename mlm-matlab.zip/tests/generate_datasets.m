clear; clc; close all; addpath(genpath('../'));
%%
experiment_config

dataset_name = 'housing';
dataset = dlmread(sprintf('../datasets/%s.csv',dataset_name));

[N] = size(dataset,1);

prop_cut = ceil(tr_prop * N);

for i=1:n_runs
    shuffle_index = randperm(N);
    index{i}.train = shuffle_index(1:prop_cut)';
    indices = crossvalind('Kfold',index{i}.train,k_fold);
        for k=1:k_fold
            test = (indices == k); 
            train = ~test;
            index{i}.folds{k}.train = find(train == 1);
            index{i}.folds{k}.test = find(test == 1);
        end
    index{i}.test  = shuffle_index(prop_cut+1:end)';     
end

clear tr_prop train test prop_cut ans k i shuffle_index indices
save(sprintf('../experiments/dataset_divisions/%s.mat',dataset_name));