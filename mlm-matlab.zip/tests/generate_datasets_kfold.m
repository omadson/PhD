clear; clc; close all; addpath(genpath('../'));
%%
experiment_config
k_fold = 5;
dataset_name = 'forestfires';
dataset = dlmread(sprintf('../datasets/%s.csv',dataset_name));

[N] = size(dataset,1);
n_runs = 5;


index_external = crossvalind('Kfold',dataset(:,end),k_fold);
for i=1:n_runs
    external_test = (index_external == i); 
    external_train = ~external_test;
    index{i}.train = find(external_train == 1);
    index{i}.test  = find(external_train == 1);
    
    index_internal = crossvalind('Kfold',index{i}.train,k_fold);
    for k=1:k_fold
        internal_test = (index_internal == k); 
        internal_train = ~internal_test;
        index{i}.folds{k}.train = find(internal_train == 1);
        index{i}.folds{k}.test = find(internal_test == 1);
    end
end

clear tr_prop train test prop_cut ans k i shuffle_index external_test external_train internal_train internal_test index_external index_internal
save(sprintf('../experiments/dataset_divisions/kfold_%s.mat',dataset_name));