clear; clc; close all; addpath(genpath('../'));
dataset_name = 'motorcycle';
experiment_name = 'esann_2019';
load(sprintf('../experiments/dataset_divisions/%s_%s.mat',experiment_name, dataset_name));


X = dataset(:,1);
y = dataset(:,2);

clf = MF_MLM(struct('lambda', 20000,'p',0.8));
clf.fit(X,y);
clf.plot();


% clf.plot();
% figure
% clf2.plot();
