clear;clc;close all;
load('../experiments/metrics/kfold_esann_2019.mat');
datasets_names = {'housing'};
for i=1:length(datasets_names)
    dataset_name = datasets_names{i};
    regressor_names = eval(sprintf('fieldnames(%s)', dataset_name));
    
    
    load(sprintf('../experiments/dataset_divisions/kfold_%s.mat',dataset_name));
    for j=1:numel(regressor_names)
        regression_name = regressor_names{j};
        metric = eval(sprintf('%s.%s', dataset_name,regression_name));
        for n=1:length(metric.model)
            y_test = dataset(index{n}.test,end);
            y_hat  = metric.y_hat_test{n};
            
            mae(n) = mean(abs(y_test - y_hat));
            mape(n) = mean(abs((y_test - y_hat)./y_test));
            rmse(n) = sqrt(mean((y_test - y_hat).^2));
            r_2(n) = 1 - mean((y_test - y_hat).^2) / mean((y_test - mean(y_test)).^2);
            
            rp_number_in(n) = length(metric.model{n}.parameters.rp_index_in);
            rp_number_out(n) = length(metric.model{n}.parameters.rp_index_out);
        end
%         plot(y_hat,y_test,'.');
        % MAE
         eval(sprintf('results_.%s.%s.mae.mean = mean(mae);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.mae.std = std(mae);', dataset_name,regression_name));
        % MAPE
        eval(sprintf('results_.%s.%s.mape.mean = mean(mape);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.mape.std = std(mape);', dataset_name,regression_name));
        % RMSE
        eval(sprintf('results_.%s.%s.rmse.mean = mean(rmse);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.rmse.std = std(rmse);', dataset_name,regression_name));
        % RMSE
        eval(sprintf('results_.%s.%s.r_2.mean = mean(r_2);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.r_2.std = std(r_2);', dataset_name,regression_name));
        
        % RP number in
        eval(sprintf('results_.%s.%s.rp_in.mean = mean(rp_number_in);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.rp_in.std = std(rp_number_in);', dataset_name,regression_name));
        
        % RP number out
        eval(sprintf('results_.%s.%s.rp_out.mean = mean(rp_number_out);', dataset_name,regression_name));
        eval(sprintf('results_.%s.%s.rp_out.std = std(rp_number_out);', dataset_name,regression_name));
    end
end