clear; clc; close all; addpath(genpath('../'));

experiment_config
%% principal loop (datasets)
for j=1:length(dataset_names)
    dataset_name = dataset_names{j};
    for k=1:length(model_names)
        model_parameters = models_parameters{k};
        variate = variates{k};
        model_name = model_names{k};
        %% load dataset and experiment setup
        try
            load(sprintf('../experiments/dataset_divisions/kfold_%s.mat',dataset_name));
        catch exception
            
        end
        metrics = struct();
        %% run loop
        for i=1:n_runs
            fprintf('\ndataset: %s | run: %d | model: %s_%s', dataset_name, i, model_name, variate);
            %% divide dataset
            % train
            X_train = dataset(index{i}.train,1:end-1);
            y_train = dataset(index{i}.train,end);
            % test
            X_test = dataset(index{i}.test,1:end-1);
            y_test = dataset(index{i}.test,end);

            %% execute crossvalidation k-fold
            crossvalidation_time = tic;
            [best_parameters] = cross_kfold(model_name,...
                                            model_parameters,...
                                            index{i}.folds,...
                                            dataset(index{i}.train,:));
            metrics.crossvalidation_time(i) = toc(crossvalidation_time); 

            %% create the model and save best parameters
            clf = eval(sprintf('%s(best_parameters);', model_name));
            metrics.best_parameters{i} = best_parameters;

            %% train best model and save time to train
            train_time            = tic;
            clf.fit(X_train, y_train);
            metrics.train_time(i) = toc(train_time);
%             metrics.model      = length();
            metrics.model{i}      = clf;

            %% compute and save predict outputs and times
            % train predict
            predict_time_train            = tic;
            metrics.y_hat_train{i}        = clf.predict(X_train);
            metrics.predict_time_train(i) = toc(predict_time_train);
            
            % test predict
            predict_time_test            = tic;
            metrics.y_hat_test{i}        = clf.predict(X_test);
            metrics.predict_time_test(i) = toc(predict_time_test);
        end
        try
           load(sprintf('../experiments/metrics/kfold_%s.mat',experiment_name));
           eval(sprintf('%s.%s_%s = metrics;', dataset_name, model_name,variate));
           save(sprintf('../experiments/metrics/kfold_%s.mat',experiment_name),dataset_name,'-append');
        catch exception
           eval(sprintf('%s.%s_%s = metrics;', dataset_name, model_name, variate));
           save(sprintf('../experiments/metrics/kfold_%s.mat',experiment_name),dataset_name);
        end
    end
end
