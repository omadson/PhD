function generate_dataset_kfold(experiment_name, dataset_name, k_out, k_in)
    dataset = dlmread(sprintf('~/Dropbox/mlm-matlab/datasets/%s.csv',dataset_name));
    
    N = size(dataset,1);
    
    index_external = crossvalind('Kfold',N,k_out);
    for i=1:k_out
        index{i}.train = find(index_external ~= i);
        index{i}.test  = find(index_external == i);
        
        N_in = size(index{i}.train,1);
        index_internal = crossvalind('Kfold',N_in,k_in);    
        for k=1:k_in
            index{i}.folds{k}.train = find((index_internal ~= k));
            index{i}.folds{k}.test  = find((index_internal == k));
        end
    end

    clear ans k i index_external index_internal N N_in
    save(sprintf('~/Dropbox/mlm-matlab/experiments/dataset_divisions/%s_%s.mat',experiment_name, dataset_name));
end